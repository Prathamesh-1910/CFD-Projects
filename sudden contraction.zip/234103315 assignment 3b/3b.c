#include<stdio.h>
#include<math.h>

int main()
{

int i,j,r,iteration=0, Re=100, m=76, n=31;
double beta,h,l,dx,dy;
double u[100][100],v[100][100],psi_prev[100][100],omega_prev[100][100],omega_m[100][100],psi[100][ 100],omega[100][100],e1[100][ 100],e2[100][ 100],e3[100][ 100];
double err_psi=0.0,err_omega=0.0;
FILE *pt1;
dx= 15.0/(m-1);
dy= 3.0/(n-1);
beta=dx/dy;
l=15;
h=3;
r=10;


/*Boundary condition for velocity*/

for(i=1;i<=m;i++) 
{ 
 u[i][1]=u[i][n]=v[i][1]=v[i][n]=0.0;
}
for(j=2;j<n;j++) 
{
 u[1][j]=v[1][j]=0.0;
}
for(j=r+1;j<=2*r;j++) 
{
 u[1][j]=1.0; v[1][j]=0.0; 
}

/*Boundary condition for streamfunction Psi*/
for(j=1;j<=n;j++) 
{
for(i=1;i<=m;i++) 
{ 
 psi_prev[i][j]=psi[i][j]=0.0;
}
}

/*Top and Bottom wall*/

for(i=1;i<=m;i++) 
{
 psi[i][1]=0.0;
} 

for(j=2;j<11;j++) 
{ 
 psi[1][j]=0.0; 
}

for(j=11;j<=21;j++)
{ 
 psi[1][j]=psi[1][j-1]+dy; 
}

for(j=22;j<n;j++) 
{ 
 psi[1][j]=psi[1][21];
}

for(i=1;i<=m;i++) 
{
 psi[i][n]=psi[1][21]; 
} 


for(j=1;j<=n;j++)
{
	for(i=1;i<=m;i++)
          {
            omega[i][j]=omega_prev[i][j]=0.0;  
          }
}

iteration=0;

do{

	for(j=1;j<=n;j++) 
	{
	for(i=1;i<=m;i++)
	 { 
	  psi_prev[i][j]=psi[i][j];
	 }
	}
	
	for(j=2;j<n;j++) 
	   {
	for(i=2;i<m;i++)
	 {
	 psi[i][j]= (dx*dx*omega[i][j] + beta*beta*(psi[i][j+1] + psi[i][j-1]) + (psi[i+1][j] + psi[i-1][j]))/(2*(1 + beta*beta));
	 }
	psi[m][j]=psi[m-1][j];
	
	   }
	
	for(j=1;j<=n;j++) for(i=1;i<=m;i++) { e1[i][j]=psi[i][j]-psi_prev[i][j];  }
	
	
	//Velocity calculation 
	
	for(j=2;j<n;j++)
	 for(i=2;i<m;i++)
	   {
	     u[i][j]=(psi[i][j+1]-psi[i][j-1])/(2*dy);
	     v[i][j]=(psi[i-1][j]-psi[i+1][j])/(2*dx);
	    }
	
	for(j=2;j<n;j++) 
	    {
	      u[m][j]=(psi[m][j]-psi[m][j-1])/dy;
	      v[m][j]=(psi[m-1][j]-psi[m][j])/dx;
	     }
	
	/*Boundary condition for vorticity Omega*/
	
	
	for(i=1;i<=m;i++)
	{ omega[i][1]=omega_prev[i][1]= 2*(psi[i][1]-psi[i][2])/(dy*dy); omega[i][n]= 2*(psi[i][n]-psi[i][n-1])/(dy*dy); }
	for(j=2;j<n;j++)
	{ omega[1][j]= 2*(psi[1][j]-psi[2][j])/(dx*dx);  }
	omega[1][11]=omega[1][11]-1.0/dy; omega[1][22]=omega[1][22]+1.0/dy;
	
	for(j=2;j<n;j++){ omega[m][j]=(2*psi[m][j]-psi[m][j-1]-psi[m][j+1])/(dy*dy); }
	
	
	
	
	for(j=2;j<n;j++) for(i=2;i<m;i++) { omega_prev[i][j]=omega[i][j];  }
	
	for(j=2;j<n;j++) 
	   {
	    for(i=2;i<m;i++) 
	        {
	          omega[i][j]=(1-(psi[i][j+1]-psi[i][j-1])*(beta*Re/4))*omega[i+1][j]+(1+(psi[i][j+1]-psi[i][j-1])*(beta*Re/4))*omega[i-1][j];
	          omega[i][j]=omega[i][j]+(1+(psi[i+1][j]- psi[i-1][j])*(Re/(4*beta)))*beta*beta*omega[i][j+1]+(1-(psi[i+1][j]-psi[i-1][j])*(Re/(4*beta)))*beta*beta*omega[i][j-1];
	          omega[i][j]=omega[i][j]/(2*(1+ beta*beta));
	          
	          omega[i][j]=omega_prev[i][j]+0.1*(omega[i][j]-omega_prev[i][j]);
	         }
	    }
	
	
	for(j=2;j<n;j++) for(i=2;i<m;i++)
	    {
	     e2[i][j]=omega[i][j]-omega_prev[i][j];
	     }
	
	err_psi=0.0;
	err_omega=0.0;
	
	for(i=2;i<m;i++)
			{
			    for(j=2;j<n;j++)
			    {
			    	err_psi = err_psi + (psi[i][j] - psi_prev[i][j])*(psi[i][j] - psi_prev[i][j]);
			    	err_omega = err_omega + (omega[i][j] - omega_prev[i][j])*(omega[i][j] - omega_prev[i][j]);
			    }
			}
			err_psi = sqrt(err_psi/((m-1)*(n-1)));
			err_omega = sqrt(err_omega/((m-1)*(n-1)));
	   
	iteration++;
	printf("ite=%d \tu[10][10]=%lf\terr_psi=%lf\terr_omega=%lf\n",iteration,u[10][10],err_psi ,err_omega);
	}
	while(err_psi> 0.000001 || err_omega> 0.000001);


    FILE *file1;
	file1 = fopen("stream.plt", "w");
	fprintf(file1, "Variables = \"X\", \"Y\", \"psi\" \n");
	
	FILE *file2;
	file2 = fopen("vorticity.plt", "w");
	fprintf(file2, "Variables = \"X\", \"Y\", \"omega\" \n");
	
	FILE *file3;
	file3 = fopen("u_velocity2.dat", "w");
	fprintf(file3, "Variables = \"u \", \"Y\" \n");
	
	FILE *file4;
	file4 = fopen("u_velocity10.dat", "w");
	fprintf(file4, "Variables = \"u\", \"Y\" \n");
	

	for(i=1;i<=m;i++)
	{
		for(j=1;j<=n;j++)
		{
		    fprintf(file1, "%lf \t %lf \t %lf \t \n", (i-1)*dx, (j-1)*dy, psi[i][j]);
		}
		    
	}
		
	for(i=1;i<=m;i++)
	{
		for(j=1;j<=n;j++)
		{
		  	fprintf(file2, "%lf \t %lf \t %lf \t \n", (i-1)*dx, (j-1)*dy, omega[i][j]);
		}
		    
	}
	
	for(j=1;j<=n;j++)
	{
		fprintf(file3,"%lf \t %lf \n", u[11][j], (j-1)*dy);	    	
	}
	
	for(j=1;j<=n;j++)
	{
		fprintf(file4,"%lf \t %lf \n", u[51][j], (j-1)*dy);	    	
	}


return 0;
}






















