#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include <sys/time.h>

void main()
{
 
  struct timeval start, end;
  long seconds, microseconds;
    gettimeofday(&start, NULL);  // Record the start time	 
  int n=101; //no. of grid points
  double dy= 1.0/(n-1);
  double Re=100.0; // Reynolds no
  double u[n], u_prev[n];
  double dt=5.0e-3; //time step
  double gamma =(dt/(Re*dy*dy));
  
 int i;
 double t=0.0;
  //initialization of BC
  FILE*fp1;
 fp1=fopen("bc.txt","w"); 
  {
   for(i=0;i<n;i++)
   {
    if(i==0)
   	{
    	u[i]=0.0;
   	}
    else if(i==(n-1))
   	{
    	u[i]=1.0;
   	}
    else
   	{
   	u[i]=0.0;
   	}
   	fprintf(fp1,"%lf \n",u[i]);
   }
   
  }
 fclose(fp1);
 
 //FTCS method
 
 int iterations=0;
 char name[50];
 float Error=0;
 FILE *fileE =fopen("Error.txt","w");
 FILE *fileq =fopen("Error vs Time.dat","w");
 do
 {
  if((iterations+100)%100==0)
  {
   sprintf(name,"velocity_%.2f.dat",t);
   FILE*fp;
   fp=fopen(name,"w");
   for(i=0;i<n;i++)
   {
   	fprintf(fp,"%lf\t%lf\n",u[i],i*dy);
   }
   fclose(fp);
  }
   for(i=0;i<n;i++)
   {
   	u_prev[i]=u[i];
   }
   for(i=1;i<(n-1);i++)
   {
   	u[i]=u_prev[i]+gamma*(u_prev[i+1]-2.0*u_prev[i]+u_prev[i-1]);
   }
   Error= 0.0;
   for(i=1;i<=n;i++)
   {
    Error = Error + pow((u[i]-u_prev[i]),2.0);
   }
    Error = sqrt(Error/(n-1));
    printf("Time = %lf \t Error = %.15lf\n",t,Error);
    fprintf(fileE,"Time = %lf \t Error = %e\n",t,Error);
    fprintf(fileq,"%lf \t %.15lf\n",t,log(Error));
    t=t+dt;
    iterations++;
 }while(t<=50.0);
 
 gettimeofday(&end, NULL); 	// Record the end time

    // Calculate the time taken
    seconds = end.tv_sec - start.tv_sec;
    microseconds = end.tv_usec - start.tv_usec;
    double elapsed = seconds + microseconds*1e-6;

    printf("Time taken: %f seconds\n", elapsed);
	fprintf(fileE,"Time taken: %f seconds\n",elapsed);
	fclose(fileE);
 
}


