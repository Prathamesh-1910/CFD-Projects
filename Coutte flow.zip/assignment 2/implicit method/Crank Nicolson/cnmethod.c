#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include <sys/time.h>

void main()
{
 
 struct timeval start, end;
    long seconds, microseconds;
    gettimeofday(&start, NULL);  // Record the start time
  int n=101; //no. of grid points
  double dy= 1.0/(n-1);
  double Re=100.0; // Reynolds no
  double u[n], u_prev[n];
  double dt=pow(10,-2); //time step
  double gamma =(dt/(2*Re*dy*dy));
  double a[n], b[n], c[n], d[n], p[n], q[n];
  
 int i;
 double t=0.0;
  //initialization of BC
  FILE*fp1;
 fp1=fopen("bc.txt","w"); 
  {
   for(i=0;i<n;i++)
   {
    if(i==0)
   	{
    	u[i]=0.0;
   	}
    else if(i==(n-1))
   	{
    	u[i]=1.0;
   	}
    else
   	{
   	u[i]=0.0;
   	}
   	fprintf(fp1,"%lf \n",u[i]);
   }
   
  }
 fclose(fp1);
 
 for(i=0;i<n;i++)
    {
        a[i] = 1+2*gamma;
        b[i] = -gamma;
        c[i] = -gamma;
    }
    b[n] = 0;
    c[1] = 0;
 
 //FTCS method
 
 int iterations=0;
 char name[50];
 float Error=0;
 FILE *fileE =fopen("Error.txt","w");
 FILE *fileq =fopen("Error vs Time.dat","w");
 do
 {
  if((iterations+100)%100==0)
  {
   sprintf(name,"velocity_%.2f.dat",t);
   FILE*fp;
   fp=fopen(name,"w");
   for(i=0;i<n;i++)
   {
   	fprintf(fp,"%lf\t%lf\n",u[i],i*dy);
   }
   fclose(fp);
  }
   for(i=0;i<n;i++)
   {
   	u_prev[i]=u[i];
   }
   
   d[1] = gamma*u_prev[2] + (1-2*gamma)*u_prev[1];
   p[1] = -b[1]/a[1];
   q[1] = d[1]/a[1];
   
   for(i=1;i<=(n-1);i++)
            {
               d[i] = gamma*u_prev[i+1] + (1-2*gamma)*u_prev[i] + gamma*u_prev[i-1];
                p[i] = -b[i]/(a[i]+(c[i]*p[i-1]));
                q[i] = (d[i]-c[i]*q[i-1])/(a[i]+(c[i]*p[i-1]));
            }
            for(i=n-2;i>1;i--)
            {
                u[i] = p[i]*u[i+1] + q[i];
            }
   
   Error= 0.0;
   for(i=1;i<=n;i++)
   {
    Error = Error + pow((u[i]-u_prev[i]),2.0);
   }
    Error = sqrt(Error/(n-1));
    printf("Time = %lf \t Error = %.15lf\n",t,Error);
    fprintf(fileE,"Time = %lf \t Error = %e\n",t,Error);
    fprintf(fileq,"%lf \t %.15lf\n",t,log(Error));
    t=t+dt;
    iterations++;
 }while(t<=50);
 gettimeofday(&end, NULL); 	// Record the end time

    // Calculate the time taken
    seconds = end.tv_sec - start.tv_sec;
    microseconds = end.tv_usec - start.tv_usec;
    double elapsed = seconds + microseconds*1e-6;

    printf("Time taken: %f seconds\n", elapsed);
 
}
