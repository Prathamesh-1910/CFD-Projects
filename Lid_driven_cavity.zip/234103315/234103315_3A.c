#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int main()
{
	int i,j,m,n,p;
	double dx,dy,x,y,Re,beta;
	
	printf("\nEnter grid size for length dimension(m):");
	scanf("%d",&m);
	printf("\nEnter grid size for length dimension(n):");
	scanf("%d",&n);
	printf("\nEnter Reynolds no:");
	scanf("%lf",&Re);
	
	p=(m-2)*(n-2); //no. off interior points
	
	dx=pow((m-1),-1);
	dy=pow((n-1),-1);
	beta=(dx/dy);
	double psi[m][n], omega[m][n], u[m][n],v[m][n];
	double psi_prev[m][n], omega_prev[m][n];
	double error_psi=0, error_omega=0;
	int iteration=1;
	FILE *fp,*fq,*fr,*fs,*ft,*fu ;
	
	//initialization and boundary condition
	FILE*fp1;
 	fp1=fopen("bc u.txt","w");
 	FILE*fp2;
 	fp2=fopen("bc v.txt","w");
 	FILE*fp3;
 	fp3=fopen("bc psi.txt","w");
	
	for(j=0;j<n;j++)
	{
		for(i=0;i<m;i++)
		{
			if(j==0)
			{
				u[i][j]=0;
				v[i][j]=0;
				psi[i][j]=0;	
				fprintf(fp1,"%lf\n",u[i][j]);
				fprintf(fp2,"%lf\n",v[i][j]);
				fprintf(fp3,"%lf\n",psi[i][j]);
			}
			else if(j==(n-1))
			{
				u[i][j]=1;
				v[i][j]=0;
				psi[i][j]=0;
				fprintf(fp1,"%lf\n",u[i][j]);
				fprintf(fp2,"%lf\n",v[i][j]);
				fprintf(fp3,"%lf\n",psi[i][j]);
			}
			else if(i==0)
			{
				u[i][j]=0;
				v[i][j]=0;
				psi[i][j]=0;
				fprintf(fp1,"%lf\n",u[i][j]);
				fprintf(fp2,"%lf\n",v[i][j]);
				fprintf(fp3,"%lf\n",psi[i][j]);
			}
			else if(i==(m-1))
			{
				u[i][j]=0;
				v[i][j]=0;
				psi[i][j]=0;
				fprintf(fp1,"%lf\n",u[i][j]);
				fprintf(fp2,"%lf\n",v[i][j]);
				fprintf(fp3,"%lf\n",psi[i][j]);
			}
			else
			{
				u[i][j]=0;
				v[i][j]=0;
				psi[i][j]=0;
				fprintf(fp1,"%lf\n",u[i][j]);
				fprintf(fp2,"%lf\n",v[i][j]);
				fprintf(fp3,"%lf\n",psi[i][j]);
			}		
		}
	}fclose(fp1);
	fclose(fp2);
	fclose(fp3);

	

//Gauss Seidel method
	do
	{
	error_psi=0;
	error_omega=0;
	
	
	for(j=0;j<n;j++)
	{
		for(i=0;i<m;i++)
		{
			if(j==0)
			{
				omega[i][j]=(2/pow(dy,2))*(psi[i][j]-psi[i][j+1]);
			}
			else if(j==(n-1))
			{
			omega[i][j]=(2/pow(dy,2))*(psi[i][j]-psi[i][j-1])-((2/dy)*u[i][j]);
			}
			else if(i==0)
			{
				omega[i][j]=(2/pow(dx,2))*(psi[i][j]-psi[i+1][j]);
			}
			else if(i==(m-1))
			{
				omega[i][j]=(2/pow(dx,2))*(psi[i][j]-psi[i-1][j]);
			}
			/*else
			{
				omega[i][j]=0;
			}*/
		}
	}
	
	
		for(j=0;j<n;j++)
		{
			for(i=0;i<m;i++)
			{
				psi_prev[i][j]=psi[i][j];
				omega_prev[i][j]=omega[i][j];		
			}
		}
		
		//solving for vorticity
		for(j=1;j<(n-1);j++)
		{
			for(i=1;i<(m-1);i++)
			{
			omega[i][j]=((1.0/(2.0*(1+pow(beta,2))))*(((1.0-((psi[i][j+1]-psi[i][j-1])*((beta*Re)/4.0)))*omega[i+1][j])
                             +((1.0+((psi[i][j+1]-psi[i][j-1])*((beta*Re)/4.0)))*omega[i-1][j])
                             +((1.0+((psi[i+1][j]-psi[i-1][j])*(Re/(4.0*beta))))*(pow(beta,2)*omega[i][j+1]))
                             +((1.0-((psi[i+1][j]-psi[i-1][j])*(Re/(4.0*beta))))*(pow(beta,2)*omega[i][j-1]))));
			}
		}
		
		//solving for stream function
		for(j=1;j<(m-1);j++)
		{
			for(i=1;i<(m-1);i++)
			{
				psi[i][j]=((1.0/(2.0*(1+pow(beta,2))))*(psi[i+1][j]+psi[i-1][j]+(pow(beta,2)*(psi[i][j+1]+psi[i][j-1]))+(pow(dx,2)*omega[i][j])));
			}
		}
		
		
		
		//Error calculation
		error_psi=0;
		error_omega=0;
		
		for(j=1;j<(n-1);j++)
		{
			for(i=1;i<(m-1);i++)
			{
				error_psi=error_psi+pow((psi[i][j]-psi_prev[i][j]),2);
				error_omega=error_omega+pow((omega[i][j]-omega_prev[i][j]),2);
			}
		}
		error_psi=sqrt(error_psi/p);
		error_omega=sqrt(error_omega/p);
		
		printf("iteration=%d\n",iteration);
		printf("error_psi=%.10lf\n error_omega=%.10lf\n\n",error_psi,error_omega);
		iteration++;	
	}
	while(error_psi>1.0e-6||error_omega>1.0e-6);
	
	//update velocities u and v
	for(j=1;j<(n-1);j++)
	{
		for(i=1;i<(m-1);i++)
		{
			u[i][j]=(0.5/dy)*(psi[i][j+1]-psi[i][j-1]);
			v[i][j]=(-0.5/dx)*(psi[i+1][j]-psi[i-1][j]);
		}
	}
 	
  FILE *f_alldat ;
  
  f_alldat= fopen("All DATA.dat", "w");

  fprintf(f_alldat, "ZONE I=%d, J=%d\n",m,n);
  for (j = 0; j < n; j++)
  {
    y = j*dy;
    for (i = 0; i < m; i++)
    {
      x= i*dx;
      fprintf(f_alldat, "%lf\t%lf\t%lf\t%lf\t%lf\t%lf\n", x,y,u[i][j],v[i][j], psi[i][j],omega[i][j]);
    }
  }
	
fp=fopen("U_graph.dat","w");
fq=fopen("V_graph.dat","w");
fr=fopen("psi_graph.dat","w");
fs=fopen("omega_graph.dat","w");
fu=fopen("u_centreline.dat","w");
ft=fopen("v_centreline.dat","w");
fprintf(fr,"VARIABLES=\"x\",\"y\",\"PSI\"\n");
fprintf(fr,"ZONE T=\"BLOCK1\",i=100,j=100,F=POINT\n\n");
for(i=0;i<m;i++)
{  for(j=0;j<n;j++)
     {
        fprintf(fr,"%lf\t%lf\t%lf\n",i*dx,j*dy,psi[i][j]);
      }
}

fprintf(fp,"VARIABLES=\"x\",\"y\",\"U\"\n");
fprintf(fp,"ZONE T=\"BLOCK1\",i=100,j=100,F=POINT\n\n");
for(i=0;i<m;i++)
{  for(j=0;j<n;j++)
     {
        fprintf(fp,"%lf\t%lf\t%lf\n",i*dx,j*dy,u[i][j]);
      }
}

fprintf(fq,"VARIABLES=\"x\",\"y\",\"V\"\n");
fprintf(fq,"ZONE T=\"BLOCK1\",i=100,j=100,F=POINT\n\n");
for(i=0;i<m;i++)
{  for(j=0;j<n;j++)
     {
        fprintf(fq,"%lf\t%lf\t%lf\n",i*dx,j*dy,v[i][j]);
      }
}



fprintf(fs,"VARIABLES=\"x\",\"y\",\"OMEGA\"\n");
fprintf(fs,"ZONE T=\"BLOCK1\",i=100,j=100,F=POINT\n\n");
for(i=0;i<m;i++)
{  for(j=0;j<n;j++)
     {
        fprintf(fs,"%lf\t%lf\t%lf\n",i*dx,j*dy,omega[i][j]);
      }
}

for(j=0;j<n;j++)
     {
        fprintf(fu,"%f\t%f\n",u[(m/2)-1][j],j*dy);
      }

for(i=0;i<m;i++)
{
        fprintf(ft,"%f\t%f\n",v[i][(n/2)-1],i*dx);
}
fclose(fp);
fclose(fq);
fclose(fr);
fclose(fs);
fclose(ft);
fclose(fu);		
	
}
